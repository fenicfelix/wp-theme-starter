<!-- Button -->
<div class="jeg_aside_item">
    <div class="jeg_nav_item jeg_button_drawer">
        <?php jnews_create_button('drawer'); ?>
    </div>
</div>