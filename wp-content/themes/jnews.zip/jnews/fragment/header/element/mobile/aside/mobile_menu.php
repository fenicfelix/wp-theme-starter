<div class="jeg_aside_item">
    <?php jnews_menu()->mobile_navigation(); ?>
</div>