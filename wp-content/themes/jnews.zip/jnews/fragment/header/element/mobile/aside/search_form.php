<!-- Search Form -->
<div class="jeg_aside_item jeg_search_wrapper jeg_search_no_expand <?php echo esc_attr(get_theme_mod('jnews_header_menu_search_form_style', 'round')) ?>">
    <a href="#" aria-label="<?php esc_html_e( 'Search Button', 'jnews' ); ?>" class="jeg_search_toggle"><i class="fa fa-search"></i></a>
    <?php get_search_form(); ?>
</div>