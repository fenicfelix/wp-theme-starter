<div class='jeg_aside_item jeg_mobile_lang_switcher'>
    <?php jnews_language_switcher(); ?>
</div>