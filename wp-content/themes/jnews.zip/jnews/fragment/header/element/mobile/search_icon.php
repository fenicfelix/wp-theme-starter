<div class="jeg_nav_item jeg_search_wrapper jeg_search_popup_expand">
    <a href="#" aria-label="<?php esc_html_e( 'Search Button', 'jnews' ); ?>" class="jeg_search_toggle"><i class="fa fa-search"></i></a>
	<?php get_search_form(); ?>
</div>