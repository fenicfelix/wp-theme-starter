<div class="jeg_nav_item jeg_nav_html">
    <?php echo do_shortcode(get_theme_mod('jnews_header_html_1', '')); ?>
</div>