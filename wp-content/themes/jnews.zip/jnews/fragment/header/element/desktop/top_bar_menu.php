<div class="jeg_nav_item">
	<?php jnews_menu()->top_navigation(); ?>
</div>