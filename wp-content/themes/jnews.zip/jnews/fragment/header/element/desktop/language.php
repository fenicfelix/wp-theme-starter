<div class='jeg_nav_item jeg_lang_switcher'>
    <?php jnews_language_switcher(); ?>
</div>
