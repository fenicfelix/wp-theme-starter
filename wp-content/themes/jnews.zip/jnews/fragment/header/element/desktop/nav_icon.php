<div class="jeg_nav_item jeg_nav_icon">
    <a href="#" aria-label="<?php esc_html_e( 'Show Menu', 'jnews' ); ?>" class="toggle_btn jeg_mobile_toggle">
    	<span></span><span></span><span></span>
    </a>
</div>