<div class="jeg_nav_item jnews_header_topbar_weather">
    <?php do_action('jnews_header_topbar_weather'); ?>
</div>