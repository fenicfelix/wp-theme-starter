<!-- Search Icon -->
<div class="jeg_nav_item jeg_search_wrapper search_icon <?php echo esc_attr(get_theme_mod('jnews_header_search_style', 'jeg_search_popup_expand')) ?>">
    <a href="#" class="jeg_search_toggle" aria-label="<?php esc_html_e( 'Search Button', 'jnews' ); ?>"><i class="fa fa-search"></i></a>
    <?php get_search_form(); ?>
</div>