<div class="jeg_nav_item">
    <a href="#" aria-label="<?php esc_html_e( 'Show Menu', 'jnews' ); ?>" class="toggle_btn jeg_mobile_toggle"><i class="fa fa-bars"></i></a>
</div>