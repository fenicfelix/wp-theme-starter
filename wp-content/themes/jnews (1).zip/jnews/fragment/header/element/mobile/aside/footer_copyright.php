<div class="jeg_aside_item jeg_aside_copyright">
	<p><?php echo jnews_get_footer_copyright(); ?></p>
</div>