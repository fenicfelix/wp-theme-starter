<div class="jeg_aside_item jeg_aside_html">
	<?php echo do_shortcode( get_theme_mod( 'jnews_header_html_drawer', '' ) ); ?>
</div>
