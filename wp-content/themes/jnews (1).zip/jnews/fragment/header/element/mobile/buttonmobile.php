<!-- Button -->
<div class="jeg_nav_item jeg_button_mobile">
    <?php jnews_create_button('mobile'); ?>
</div>