<div class="jeg_aside_item socials_widget <?php echo esc_attr(get_theme_mod('jnews_header_social_icon', 'nobg')) ?>">
    <?php jnews_generate_social_icon_block(); ?>
</div>