<div class="jeg_nav_item jeg_main_menu_wrapper">
<?php
    jnews_menu()->main_navigation();
    do_action('jnews_main_menu');
?>
</div>
