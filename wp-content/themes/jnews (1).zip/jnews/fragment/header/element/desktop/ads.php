<div class="jeg_nav_item jeg_ad jeg_ad_top jnews_header_ads">
    <?php do_action('jnews_header_ads'); ?>
</div>