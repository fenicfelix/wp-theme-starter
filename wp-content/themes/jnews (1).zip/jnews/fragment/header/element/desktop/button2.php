<!-- Button -->
<div class="jeg_nav_item jeg_button_2">
    <?php jnews_create_button(2); ?>
</div>