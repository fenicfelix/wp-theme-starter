<?php
/**
 * Option Control Field Impexp
 *
 * @author Jegtheme
 * @package JNews\Dashboard\Panel\Option
 */

namespace JNews\Dashboard\Panel\Option;

/**
 * Class OptionControlFieldImpexp.
 */
class OptionControlFieldImpexp extends OptionControlField {

	public function fetch_data() {
		return $this->get_data();
	}

}
