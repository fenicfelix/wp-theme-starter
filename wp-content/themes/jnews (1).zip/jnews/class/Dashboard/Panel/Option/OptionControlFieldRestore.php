<?php
/**
 * Option Control Field Restore
 *
 * @author Jegtheme
 * @package JNews\Dashboard\Panel\Option
 */

namespace JNews\Dashboard\Panel\Option;

/**
 * Class OptionControlFieldRestore.
 */
class OptionControlFieldRestore extends OptionControlField {

	public function fetch_data() {
		return $this->get_data();
	}

}