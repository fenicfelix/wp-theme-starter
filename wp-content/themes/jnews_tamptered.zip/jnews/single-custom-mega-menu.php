<?php get_header(); ?>

<div class="jeg_main">
    <div class="jeg_container">
        <div class="jeg_content">
            <div class="content-placeholder">
                <div class="jeg_container">
                    <div class="container">
                        <div class="row">
                            <div class="jeg_main_content col-md-8">
                                <div class="placeholder_title"></div>
                                <div class="placeholder_title w60"></div>
                                <div class="placeholder_img"></div>
                                <div class="placeholder_text"></div>
                                <div class="placeholder_text"></div>
                                <div class="placeholder_text"></div>
                                <div class="placeholder_text w60"></div>
                            </div>
                            <div class="jeg_sidebar col-md-4">
                                <div class="placeholder_widget"></div>
                                <div class="placeholder_text"></div>
                                <div class="placeholder_text w60"></div>
                                <br>
                                <div class="placeholder_widget"></div>
                                <div class="placeholder_text"></div>
                                <div class="placeholder_text w60"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php get_footer(); ?>