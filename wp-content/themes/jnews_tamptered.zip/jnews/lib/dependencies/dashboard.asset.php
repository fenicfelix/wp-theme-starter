<?php return array('dependencies' => array('lodash', 'react', 'react-dom', 'wp-api-fetch', 'wp-data', 'wp-hooks', 'wp-i18n'), 'version' => '8fefdb0636e7f401ee23');
