<?php

class JNews_Block_1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_3_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_4_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_5_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_6_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_7_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_8_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_9_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_10_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_11_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_12_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_13_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_14_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_15_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_16_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_17_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_18_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_19_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_20_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_21_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_22_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_23_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_24_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_25_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_26_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_27_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_28_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_29_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_30_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_31_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_32_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_33_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_34_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_35_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_36_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_37_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_38_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Block_39_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_3_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_4_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_5_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_6_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_7_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_8_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_9_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_10_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_11_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_12_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_13_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_14_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Hero_Skew_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_3_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_4_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_5_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_6_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_7_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_8_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_9_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Rss_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Slider_Overlay_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Header_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Ads_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Blocklink_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Newsticker_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Subscribe_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Videoplaylist_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Userlist_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Embedplaylist_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Splitnav_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Iconlink_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Carousel_1_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Carousel_2_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Carousel_3_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Footer_Menu_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Footer_Social_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Footer_Instagram_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Footer_Tiktok_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Footer_Header_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Review_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Review_Shortcode_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Push_Notification_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Post_Package_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Paywall_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Element_Donation_Button_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Title_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Subtitle_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Breadcrumb_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Meta_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Feature_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Content_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Share_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Tag_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Author_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Sequence_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Comment_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Related_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Post_Source_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Block_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Breadcrumb_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Desc_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Hero_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Pagination_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Archive_Title_Elementor extends \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Categorylist_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Videoheader_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Block1_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Block2_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Block3_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Block4_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Carousel1_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Carousel2_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Carousel3_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Carousel4_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Carouselplaylist_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}

class JNews_Video_Blockplaylist_Elementor extends  \JNews\Elementor\ModuleElementorAbstract {}
