<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_FacebookPage_View extends WidgetViewAbstract
{
}