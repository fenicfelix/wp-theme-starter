<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Popular_View extends WidgetViewAbstract
{
}