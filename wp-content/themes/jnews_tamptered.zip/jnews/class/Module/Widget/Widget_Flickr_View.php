<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Flickr_View extends WidgetViewAbstract
{
}