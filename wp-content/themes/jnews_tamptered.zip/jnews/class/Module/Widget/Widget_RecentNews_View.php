<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_RecentNews_View extends WidgetViewAbstract
{
}