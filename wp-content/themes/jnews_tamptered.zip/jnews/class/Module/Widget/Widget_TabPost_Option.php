<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_TabPost_Option extends WidgetOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('JNews - Tab Post Widget', 'jnews');
    }
}