<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Twitter_View extends WidgetViewAbstract
{
}