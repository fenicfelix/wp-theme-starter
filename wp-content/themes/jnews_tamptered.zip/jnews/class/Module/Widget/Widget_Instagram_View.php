<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Instagram_View extends WidgetViewAbstract
{
}