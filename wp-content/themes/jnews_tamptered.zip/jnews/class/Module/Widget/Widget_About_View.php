<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_About_View extends WidgetViewAbstract
{
}