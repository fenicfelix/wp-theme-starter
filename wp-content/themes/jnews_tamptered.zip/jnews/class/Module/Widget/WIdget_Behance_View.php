<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Behance_View extends WidgetViewAbstract
{
}