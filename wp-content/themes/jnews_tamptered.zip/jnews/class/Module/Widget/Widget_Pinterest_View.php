<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_Pinterest_View extends WidgetViewAbstract
{
}