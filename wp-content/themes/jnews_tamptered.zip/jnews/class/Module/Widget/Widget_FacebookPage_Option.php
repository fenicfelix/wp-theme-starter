<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_FacebookPage_Option extends WidgetOptionAbstract
{
    public function get_module_name()
    {
        return esc_html__('JNews - Facebook Page Widget', 'jnews');
    }
}