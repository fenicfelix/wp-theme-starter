<?php
/**
 * @author : Jegtheme
 */
namespace JNews\Module\Widget;

Class Widget_TabPost_View extends WidgetViewAbstract
{
}