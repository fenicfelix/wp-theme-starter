<?php

/********* BLOCK *********/

class JNews_Block_1_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_2_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_3_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_4_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_5_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_6_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_7_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_8_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_9_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_10_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_11_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_12_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_13_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_14_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_15_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_16_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_17_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_18_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_19_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_20_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_21_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_22_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_23_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_24_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_25_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_26_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_27_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_28_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_29_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_31_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_32_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_33_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_34_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_35_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_36_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_37_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_38_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Block_39_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Block1_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Block2_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Block3_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Block4_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Blockplaylist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

/********* ELEMENT *********/

class JNews_Element_Ads_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Element_Embedplaylist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Element_Header_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Element_Videoplaylist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Element_Userlist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Video_Videoheader_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

class JNews_Element_Subscribe_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

/********* SLIDER *********/

class JNews_Slider_3_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {

}

/********* CAROUSEL *********/
class JNews_Video_Categorylist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

class JNews_Video_Carousel1_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

class JNews_Video_Carousel2_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

class JNews_Video_Carousel3_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

class JNews_Video_Carousel4_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

class JNews_Video_Carouselplaylist_Widget extends \JNews\Widget\Module\WidgetModuleAbstract {
}

