<?php

class About_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Line_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Popular_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Recent_News_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Social_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Social_Counter_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Facebook_Page_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Twitter_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Pinterest_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Instagram_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Flickr_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Behance_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Tab_Post_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Tiktok_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}

class Donation_Widget extends \JNews\Widget\Normal\WidgetNormalAbstract {

}
